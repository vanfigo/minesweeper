package com.bucketdev.betapp.domain;

import javax.persistence.Entity;

@Entity
public class User {

}
